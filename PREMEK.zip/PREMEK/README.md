
#### CARA INSTALL SCRIPT:
 download aplikasi termux android di [sini!](https://f-droid.org/repo/com.termux_117.apk), lalu buka aplikasinya ketikan perintah dibawah ini.
 ```
 $ pkg update && pkg upgrade
 $ pkg install python git
 $ pkg install play-audio
 $ pip install requests bs4 futures
 $ rm -rf BACEM
 $ git clone https://github.com/Xyaa-Code/BACEM
 ```
 oke sekarang script sudah terinstall
##### CARA MENJALANKAN SCRIPT:
 sekarang karena script sudah diinstall tinggal kita jalankan, ketikan perintah dibawah ini:
 ```
  $ cd BACEM
  $ git pull
  $ python run.py
 ```
##### TAMPILAN MENU:
![template_s](https://github.com/Xyaa-Code/BACEM/blob/main/data/img/IMG_20230217_141313.jpg)

##### MENU BOT:
![template_s](https://github.com/Xyaa-Code/BACEM/blob/main/data/img/IMG_20230217_141254.jpg)

##### HASIL CRACK:
![template_s](https://github.com/Xyaa-Code/BACEM/blob/main/data/img/IMG_20230217_181436.jpg)

##### info:
 untuk versi sekarang hanya support di perangkat yang *aarch64* untuk mengecek
 ketik perintah ini : ```uname -m``` jika muncul *aarch64* selamat anda bisa menggunakan script ini,
 oh iya script ini juga cuma bisa dijalanin dipython versi 3.11 untuk mengecek versi python
 ketik perintah ini : ```python --version```

##### catatan:
 gunakanlah dengan bijak, atas apapun yang terjadi admin tidak bertanggung jawab.

###### Thanks for [Xyaa-Code](https://github.com/Xyaa-Code) and [AdtyaXC](https://github.com/AdtyaXC)
